// A-Gent Popup Script - AI Workstamp

const signupScreen = document.getElementById('signupScreen');
const dashboardScreen = document.getElementById('dashboardScreen');
const emailInput = document.getElementById('emailInput');
const startBtn = document.getElementById('startBtn');
const viewDashboardBtn = document.getElementById('viewDashboardBtn');

// Check state on load
chrome.storage.local.get(['userEmail', 'isTracking'], (result) => {
  if (result.userEmail && result.isTracking) {
    showDashboard();
    refreshStats();
  } else {
    showSignup();
  }
});

startBtn.addEventListener('click', () => {
  const email = emailInput.value.trim();
  if (!email || !email.includes('@')) {
    emailInput.style.borderColor = '#ef4444';
    setTimeout(() => emailInput.style.borderColor = '', 1000);
    return;
  }
  
  chrome.runtime.sendMessage({ action: 'startTracking', email }, (response) => {
    if (response.success) {
      showDashboard();
      refreshStats();
    }
  });
});

viewDashboardBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://dashboard.a-gent.co/' });
});

function showSignup() {
  signupScreen.classList.remove('hidden');
  dashboardScreen.classList.add('hidden');
}

function showDashboard() {
  signupScreen.classList.add('hidden');
  dashboardScreen.classList.remove('hidden');
  refreshStats();
  
  // Refresh every 30 seconds
  setInterval(refreshStats, 30000);
}

function refreshStats() {
  chrome.runtime.sendMessage({ action: 'getWorkstamp' }, (response) => {
    if (!response || !response.workstamp) return;
    
    const ws = response.workstamp;
    
    // Update stats
    document.getElementById('totalHours').textContent = ws.totalHours || '0.0';
    document.getElementById('sessionCount').textContent = ws.sessionCount || '0';
    document.getElementById('topCategory').textContent = ws.categoryBreakdown?.[0]?.label || '--';
    
    // Render insights
    const insightsList = document.getElementById('insightsList');
    if (ws.insights && ws.insights.length > 0) {
      insightsList.innerHTML = ws.insights.map(insight => `
        <div class="insight-card insight-type-${insight.type}">
          <span class="insight-icon">${insight.icon}</span>
          <span class="insight-text">${insight.text}</span>
        </div>
      `).join('');
    } else {
      insightsList.innerHTML = '<div class="empty-state">Keep browsing — insights coming soon...</div>';
    }
    
    // Render categories
    const categoryList = document.getElementById('categoryList');
    if (ws.categoryBreakdown && ws.categoryBreakdown.length > 0) {
      categoryList.innerHTML = ws.categoryBreakdown.map(cat => `
        <div class="category-row">
          <div class="category-dot dot-${cat.category}"></div>
          <span class="category-name">${cat.label}</span>
          <span class="category-time">${cat.hours}h</span>
          <span class="category-pct">${cat.percentage}%</span>
        </div>
      `).join('');
    } else {
      categoryList.innerHTML = '<div class="empty-state">Start browsing to see your activity...</div>';
    }
    
    // Update status
    document.getElementById('statusText').textContent = ws.sessionCount > 0 ? 'Active' : 'Recording';
  });
}

// Auto-refresh stats when tab becomes active
chrome.tabs.onActivated.addListener(() => {
  if (!signupScreen.classList.contains('hidden')) return;
  refreshStats();
});