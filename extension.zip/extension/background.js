// A-Gent AI Workstamp - Background Service Worker
// Captures work activity, detects patterns, generates insights

const STORAGE_KEY = 'agent_data';
const WORKSTAMP_INTERVAL = 60000; // 1 minute
const SEQUENCE_WINDOW = 300000; // 5 minutes

let state = {
  isTracking: false,
  userEmail: null,
  sessionStart: null,
  currentTab: null,
  activityBuffer: [],
  dailyWorkstamp: null,
  lastActivityTime: null
};

// Category mapping with deeper detection
const categoryMap = {
  // Email
  'mail.google.com': 'email',
  'outlook.live.com': 'email',
  'outlook.office365.com': 'email',
  'mail.yahoo.com': 'email',
  'fastmail.com': 'email',
  'superhuman.com': 'email',
  
  // CRM
  'salesforce.com': 'crm',
  'hubspot.com': 'crm',
  'dynamics.microsoft.com': 'crm',
  'pipedrive.com': 'crm',
  'zoho.com': 'crm',
  
  // Communication
  'slack.com': 'comm',
  'teams.microsoft.com': 'comm',
  'discord.com': 'comm',
  'zoom.us': 'comm',
  'meet.google.com': 'comm',
  
  // Research / Discovery
  'linkedin.com': 'research',
  'twitter.com': 'research',
  'x.com': 'research',
  'crunchbase.com': 'research',
  'apollo.io': 'research',
  'hunter.io': 'research',
  'databox.com': 'research',
  
  // Documents / Notes
  'docs.google.com': 'docs',
  'notion.so': 'docs',
  'evernote.com': 'docs',
  'dropbox.com': 'docs',
  'sharepoint.com': 'docs',
  
  // Pipeline / Tasks
  'asana.com': 'tasks',
  'linear.app': 'tasks',
  'monday.com': 'tasks',
  'jira.atlassian.com': 'tasks',
  'trello.com': 'tasks'
};

// Page intent detection based on URL patterns
const intentPatterns = {
  'linkedin.com/sales': 'prospecting',
  'linkedin.com/in/': 'prospecting',
  'apollo.io/search': 'prospecting',
  'hunter.io/search': 'prospecting',
  'docs.google.com/document': 'drafting',
  'notion.so': 'planning',
  'salesforce.com/lightning/r/': 'crm_entry',
  'hubspot.com/contacts': 'crm_entry',
  'mail.google.com': 'composing',
  'outlook.live.com': 'composing'
};

function getCategory(url) {
  try {
    const hostname = new URL(url).hostname;
    return categoryMap[hostname] || detectIntent(url) || 'other';
  } catch {
    return 'other';
  }
}

function detectIntent(url) {
  for (const [pattern, intent] of Object.entries(intentPatterns)) {
    if (url.includes(pattern)) return intent;
  }
  return null;
}

function getIntentLabel(intent) {
  const labels = {
    'prospecting': 'Prospecting',
    'drafting': 'Drafting',
    'planning': 'Planning',
    'crm_entry': 'CRM Entry',
    'composing': 'Composing'
  };
  return labels[intent] || 'Working';
}

function recordActivity(tabId, url, category, intent) {
  const activity = {
    timestamp: Date.now(),
    tabId,
    url,
    domain: new URL(url).hostname,
    category,
    intent: intent || getIntentLabel(category),
    duration: 0
  };
  
  // Update duration of last activity if same tab
  if (state.activityBuffer.length > 0) {
    const last = state.activityBuffer[state.activityBuffer.length - 1];
    if (last.tabId === tabId && last.url === url) {
      last.duration = Math.floor((Date.now() - last.timestamp) / 1000);
    }
  }
  
  state.activityBuffer.push(activity);
  state.lastActivityTime = Date.now();
  saveState();
}

function generateWorkstamp() {
  const now = new Date();
  const today = now.toISOString().split('T')[0];
  
  // Group activities by category
  const categoryTime = {};
  const intentTime = {};
  const domainFrequency = {};
  const sequencePatterns = [];
  
  let totalSeconds = 0;
  
  state.activityBuffer.forEach(a => {
    const hours = (a.duration || 0) / 3600;
    totalSeconds += a.duration || 0;
    
    // Category
    categoryTime[a.category] = (categoryTime[a.category] || 0) + (a.duration || 0);
    
    // Intent
    if (a.intent) {
      intentTime[a.intent] = (intentTime[a.intent] || 0) + (a.duration || 0);
    }
    
    // Domain frequency
    domainFrequency[a.domain] = (domainFrequency[a.domain] || 0) + 1;
    
    // Sequence patterns (what transitions to what)
    const idx = state.activityBuffer.indexOf(a);
    if (idx > 0) {
      const prev = state.activityBuffer[idx - 1];
      if (prev && (a.timestamp - prev.timestamp) < SEQUENCE_WINDOW) {
        const key = `${prev.category}→${a.category}`;
        sequencePatterns[key] = (sequencePatterns[key] || 0) + 1;
      }
    }
  });
  
  // Top domains
  const topDomains = Object.entries(domainFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([domain, count]) => ({ domain, count }));
  
  // Top sequences
  const topSequences = Object.entries(sequencePatterns)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([pattern, count]) => ({ pattern, count }));
  
  // Category breakdown
  const categoryBreakdown = Object.entries(categoryTime)
    .map(([cat, secs]) => ({
      category: cat,
      label: capitalize(cat),
      hours: (secs / 3600).toFixed(1),
      percentage: Math.round((secs / totalSeconds) * 100) || 0
    }))
    .sort((a, b) => b.hours - a.hours);
  
  // Intent breakdown
  const intentBreakdown = Object.entries(intentTime)
    .map(([intent, secs]) => ({
      intent,
      label: capitalize(intent),
      hours: (secs / 3600).toFixed(1),
      percentage: Math.round((secs / totalSeconds) * 100) || 0
    }))
    .sort((a, b) => b.hours - a.hours);
  
  // AI Coaching insights
  const insights = generateInsights(categoryBreakdown, intentBreakdown, topSequences, totalSeconds);
  
  const workstamp = {
    date: today,
    email: state.userEmail,
    totalHours: (totalSeconds / 3600).toFixed(1),
    sessionCount: state.activityBuffer.length,
    topDomains,
    topSequences,
    categoryBreakdown,
    intentBreakdown,
    insights,
    generatedAt: now.toISOString()
  };
  
  state.dailyWorkstamp = workstamp;
  return workstamp;
}

function generateInsights(categoryBreakdown, intentBreakdown, topSequences, totalSeconds) {
  const insights = [];
  
  // Benchmark comparison (industry avg for sales reps)
  const benchmarks = {
    'prospecting': 1.5, // hours/day
    'crm': 1.0,
    'comm': 2.0,
    'research': 1.0,
    'docs': 0.5
  };
  
  // Compare to benchmark
  categoryBreakdown.forEach(cat => {
    const bench = benchmarks[cat.category];
    if (bench) {
      const actual = parseFloat(cat.hours);
      if (actual < bench * 0.7) {
        insights.push({
          type: 'opportunity',
          icon: '⚡',
          text: `You spend ${cat.hours}h on ${cat.label} vs benchmark ${bench}h. That's an opportunity area.`
        });
      } else if (actual > bench * 1.3) {
        insights.push({
          type: 'high_performer',
          icon: '🎯',
          text: `Strong focus on ${cat.label} — ${cat.hours}h, above typical benchmarks.`
        });
      }
    }
  });
  
  // Sequence pattern insights
  if (topSequences.length > 0) {
    const top = topSequences[0];
    if (top.pattern.includes('→')) {
      insights.push({
        type: 'pattern',
        icon: '🔄',
        text: `Most common workflow: ${top.pattern.replace('→', ' → ')} (${top.count} times)`
      });
    }
  }
  
  // High activity insight
  if (parseFloat(totalSeconds / 3600) > 6) {
    insights.push({
      type: 'engagement',
      icon: '🔥',
      text: `Solid activity day — ${(totalSeconds / 3600).toFixed(1)} hours tracked.`
    });
  }
  
  // Discovery: too little prospecting?
  const prospecting = intentBreakdown.find(i => i.intent === 'prospecting');
  if (prospecting && parseFloat(prospecting.hours) < 1) {
    insights.push({
      type: 'tip',
      icon: '💡',
      text: `Low prospecting time today. Top reps research 30+ min before first contact.`
    });
  }
  
  return insights.slice(0, 4); // max 4 insights
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Tab tracking
chrome.tabs.onActivated.addListener((activeInfo) => {
  if (!state.isTracking || !state.userEmail) return;
  
  recordPreviousActivity();
  
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab && tab.url && !isChromeInternal(tab.url)) {
      state.currentTab = { id: tab.id, url: tab.url };
      state.sessionStart = Date.now();
      const cat = getCategory(tab.url);
      const intent = detectIntent(tab.url);
      recordActivity(tab.id, tab.url, cat, intent);
    }
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!state.isTracking || !state.userEmail) return;
  
  if (changeInfo.url && state.currentTab && state.currentTab.id === tabId) {
    recordPreviousActivity();
    state.currentTab = { id: tabId, url: changeInfo.url };
    state.sessionStart = Date.now();
    const cat = getCategory(changeInfo.url);
    const intent = detectIntent(changeInfo.url);
    recordActivity(tabId, changeInfo.url, cat, intent);
  }
});

function recordPreviousActivity() {
  if (state.currentTab && state.sessionStart) {
    const duration = Math.floor((Date.now() - state.sessionStart) / 1000);
    if (duration >= 10) { // Only record 10+ second visits
      const cat = getCategory(state.currentTab.url);
      const intent = detectIntent(state.currentTab.url);
      recordActivity(state.currentTab.id, state.currentTab.url, cat, intent);
    }
  }
}

function isChromeInternal(url) {
  return url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('about:');
}

// Periodic workstamp generation every minute
setInterval(() => {
  if (!state.isTracking || !state.userEmail) return;
  
  // Update current activity duration
  if (state.currentTab && state.activityBuffer.length > 0) {
    const last = state.activityBuffer[state.activityBuffer.length - 1];
    if (last && last.tabId === state.currentTab.id) {
      last.duration = Math.floor((Date.now() - state.sessionStart) / 1000);
    }
  }
  
  // Save state
  saveState();
}, WORKSTAMP_INTERVAL);

// Persist state
function saveState() {
  chrome.storage.local.set({
    isTracking: state.isTracking,
    userEmail: state.userEmail,
    activityBuffer: state.activityBuffer,
    dailyWorkstamp: state.dailyWorkstamp,
    lastUpdated: Date.now()
  });
}

function loadState() {
  chrome.storage.local.get(['isTracking', 'userEmail', 'activityBuffer', 'dailyWorkstamp'], (result) => {
    if (result.isTracking !== undefined) state.isTracking = result.isTracking;
    if (result.userEmail) state.userEmail = result.userEmail;
    if (result.activityBuffer) state.activityBuffer = result.activityBuffer;
    if (result.dailyWorkstamp) state.dailyWorkstamp = result.dailyWorkstamp;
  });
}

// Messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startTracking') {
    state.userEmail = request.email;
    state.isTracking = true;
    state.activityBuffer = [];
    state.dailyWorkstamp = null;
    saveState();
    sendResponse({ success: true });
  }
  
  if (request.action === 'stopTracking') {
    state.isTracking = false;
    saveState();
    sendResponse({ success: true });
  }
  
  if (request.action === 'getWorkstamp') {
    const workstamp = generateWorkstamp();
    sendResponse({ workstamp, isTracking: state.isTracking });
  }
  
  if (request.action === 'getQuickStats') {
    const ws = generateWorkstamp();
    sendResponse({
      totalHours: ws.totalHours,
      sessionCount: ws.sessionCount,
      topCategory: ws.categoryBreakdown[0]?.label || 'None',
      topCategoryHours: ws.categoryBreakdown[0]?.hours || '0',
      isTracking: state.isTracking
    });
  }
  
  return true;
});

// Initialize
loadState();